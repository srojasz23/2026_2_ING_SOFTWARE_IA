# Módulos y Paquetes para Machine Learning con Python — Trabajo Final

Caso práctico: predicción de tendencia de precios para **Bursátil Perú Data**,
usando módulos y paquetes de Python para Machine Learning en un contexto
empresarial.

## Contenido

```
src/
  analista_bursatil.py   -> pipeline completo del caso practico
outputs/
  grafico_bursatil_peru_data.png -> resultado de ejemplo generado por el script
```

## Qué hace el script

`AnalistaBursatil` es una clase que recorre todo el flujo propuesto:

1. Genera / carga los datos de precios y volumen (Pandas, Numpy)
2. Calcula variables derivadas: retorno diario, promedio móvil, volatilidad
3. Entrena un modelo de clasificación con Scikit-learn (Gradient Boosting)
   para predecir si el precio sube o baja al día siguiente
4. Analiza el tono de reportes financieros de ejemplo con NLTK y mide su
   relación estadística con el retorno real usando SciPy
5. Genera gráficos comparativos con Matplotlib y Seaborn

## Cómo correrlo

```bash
pip install -r requirements.txt
python src/analista_bursatil.py
```

El script no depende de un dataset externo: genera datos simulados para
poder ejecutarse de punta a punta. Si se cuenta con el CSV real del curso,
basta con reemplazar el método `cargar_datos()`.

## Autor

Estrella — Tecnologías de la Información, SENATI
